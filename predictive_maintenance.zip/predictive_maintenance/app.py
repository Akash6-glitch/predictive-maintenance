import streamlit as st
import pandas as pd
import random
from sklearn.ensemble import RandomForestClassifier
import matplotlib.pyplot as plt
import time
import random
from streamlit_autorefresh import st_autorefresh
# -------------------------------
# Fake Dataset
# -------------------------------

data = {
    "Temperature": [40, 45, 50, 55, 60, 70, 80, 90],
    "Vibration": [0.2, 0.3, 0.4, 0.5, 0.7, 0.8, 1.0, 1.2],
    "RPM": [1000, 1200, 1300, 1400, 1500, 1700, 1900, 2100],
    "Current": [2, 3, 4, 5, 6, 7, 8, 10],
    "Status": [0, 0, 0, 0, 1, 1, 1, 1]
}

df = pd.DataFrame(data)

X = df[["Temperature", "Vibration", "RPM", "Current"]]
y = df["Status"]

# -------------------------------
# Train AI Model
# -------------------------------

model = RandomForestClassifier()
model.fit(X, y)

# -------------------------------
# Streamlit UI
# -------------------------------
# Generate Sensor Values
temperature = random.randint(30, 100)
vibration = round(random.uniform(0.1, 1.5), 2)
rpm = random.randint(800, 3000)
current = random.randint(1, 15)


st.title("🏭 AI Predictive Maintenance Dashboard")
st.sidebar.title("⚙ System Info")
st.sidebar.write("Project Name:")
st.sidebar.success("AI Predictive Maintenance")
st.sidebar.write("Model Used:")
st.sidebar.info("Random Forest Classifier")
st.sidebar.write("Status:")
st.sidebar.success("System Active")
st_autorefresh(interval=5000, key="datarefresh")

col1, col2, col3, col4 = st.columns(4)

col1.metric("🌡 Temperature", f"{temperature} °C")
col2.metric("📳 Vibration", vibration)
col3.metric("⚙ RPM", rpm)
col4.metric("⚡ Current", f"{current} A")

st.write("Monitor machine health using AI prediction.")



# Predict
prediction = model.predict([[temperature, vibration, rpm, current]])
health = 100 - ((temperature/100)*30 +
                (vibration/1.5)*30 +
                (current/15)*20 +
                (rpm/3000)*20)

if prediction[0] == 0:
    st.success("🟢 MACHINE RUNNING NORMALLY")
else:
    st.error("🔴 MACHINE FAULT DETECTED")

health = max(0, int(health))

st.subheader("Machine Health")

st.progress(health)

st.write(f"Health Score: {health}%")

st.subheader("Prediction Result")

if prediction[0] == 0:
    st.success("✅ Machine Status: NORMAL")
else:
    st.error("⚠️ Machine Status: FAULT DETECTED")

# -------------------------------
# Graph
# -------------------------------
history = pd.DataFrame({
    "Temperature": [temperature],
    "Vibration": [vibration],
    "RPM": [rpm],
    "Current": [current],
    "Prediction": ["NORMAL" if prediction[0] == 0 else "FAULT"]
})

st.subheader("Fault History")

st.table(history)

st.subheader("Sensor Monitoring")

fig, ax = plt.subplots()

ax.bar(
    ["Temperature", "Vibration", "RPM", "Current"],
    [temperature, vibration, rpm, current]
)

st.pyplot(fig)

# -------------------------------
# Extra Info
# -------------------------------

st.write("This prototype predicts machine faults using AI.")
st.caption("Developed for Industrial Predictive Maintenance Review")